package paseo;

public class Paseo {


    public static void main(String[] args) {
        int sillasPorBus = 50;
        int estudiantesGordos = 20;
        int estudiantesFlacos = 80;
        
        int busesNecesarios = calcularBusesNecesarios(sillasPorBus, estudiantesGordos, estudiantesFlacos);
        
        System.out.println("Numero de buses necesarios: " + busesNecesarios);
    }

    public static int calcularBusesNecesarios(int sillasPorBus, int gordos, int flacos) {
        int sillasNecesarias = (gordos * 2) + flacos;
        int buses = sillasNecesarias / sillasPorBus;
        if (sillasNecesarias % sillasPorBus > 0) {
            buses++;
        }
        
        return buses;
    }
}