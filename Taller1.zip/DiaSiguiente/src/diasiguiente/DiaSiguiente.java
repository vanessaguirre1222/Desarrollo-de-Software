/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package diasiguiente;

import java.util.Scanner;

public class DiaSiguiente {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el nombre de un dia de la semana:");
        String diaActual = scanner.nextLine().toLowerCase();

        String diaSig = diaSiguiente(diaActual);
        if (diaSig.equals("Dia inválido")) {
            System.out.println("Error: El dia ingresado no es valido.");
        } else {
            System.out.println("El dia siguiente a " + diaActual + " es: " + diaSig);
        }
    }

    public static String diaSiguiente(String diaActual) {
        switch (diaActual) {
            case "lunes":
                return "Martes";
            case "martes":
                return "Miércoles";
            case "miércoles":
                return "Jueves";
            case "jueves":
                return "Viernes";
            case "viernes":
                return "Sábado";
            case "sábado":
                return "Domingo";
            case "domingo":
                return "Lunes";
            default:
                return "Día inválido";
        }
    }
}
