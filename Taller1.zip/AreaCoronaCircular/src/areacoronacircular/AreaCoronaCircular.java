package areacoronacircular;

public class AreaCoronaCircular {

    public static void main(String[] args) {
        double radioPequeno = 3.0;
        double radioGrande = 5.0;

        double areaCorona = calcularAreaCoronaCircular(radioPequeno, radioGrande);

        // Mostrar el resultado
        System.out.println("El area de la corona circular es: " + areaCorona);
    }

    public static double calcularAreaCirculo(double radio) {
        return Math.PI * Math.pow(radio, 2);
    }

    public static double calcularAreaCoronaCircular(double radioPequeno, double radioGrande) {
        double areaGrande = calcularAreaCirculo(radioGrande);
        double areaPequena = calcularAreaCirculo(radioPequeno);

        return areaGrande - areaPequena;
    }
}
