package finanzaspedro;

public class FinanzasPedro {

    public static void main(String[] args) {
        double sueldoPedro = 3000.0;

        double gastoArriendo = calcularGastoArriendo(sueldoPedro);
        double gastoComida = calcularGastoComida(sueldoPedro);
        double dineroRestante = sueldoPedro - (gastoArriendo + gastoComida);

        System.out.println("Gasto en arriendo: $" + gastoArriendo);
        System.out.println("Gasto en comida: $" + gastoComida);
        System.out.println("Dinero restante despues de gastos: $" + dineroRestante);
    }

    public static double calcularGastoArriendo(double sueldo) {
        return sueldo * 0.40;
    }

    public static double calcularGastoComida(double sueldo) {
        return sueldo * 0.15;
    }
}
