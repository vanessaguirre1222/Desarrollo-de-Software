package escalera;

public class Escalera {


    public static void main(String[] args) {

        double altura = 5.0; 
        double angulo = 45; 

        double longitudEscalera = calcularLongitudEscalera(altura, angulo);

        System.out.println("La longitud de la escalera es: " + longitudEscalera + " metros");
    }

    public static double calcularLongitudEscalera(double x, double alpha) {
        double anguloEnRadianes = Math.toRadians(alpha);
        
        double y = x / Math.sin(anguloEnRadianes);
        
        return y;
    }
}
