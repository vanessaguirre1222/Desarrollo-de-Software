package edificiouniversitario;

import java.util.Scanner;

public class EdificioUniversitario {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Ingrese el numero total de estudiantes en la universidad:");
        int numeroEstudiantes = scanner.nextInt();
        System.out.println("Ingrese la capacidad de estudiantes por salon:");
        int capacidadSalon = scanner.nextInt();
        System.out.println("Ingrese el numero de salones por piso:");
        int salonesPorPiso = scanner.nextInt();
        
        int totalSalones = calcularNumeroSalones(numeroEstudiantes, capacidadSalon);
        int totalPisos = calcularNumeroPisos(totalSalones, salonesPorPiso);
        
        System.out.println("Número total de salones necesarios: " + totalSalones);
        System.out.println("Número total de pisos necesarios: " + totalPisos);
    }

    public static int calcularNumeroSalones(int estudiantes, int capacidad) {
        int salones = estudiantes / capacidad;
        if (estudiantes % capacidad > 0) {
            salones++;
        }
        return salones;
    }

    public static int calcularNumeroPisos(int salones, int salonesPorPiso) {
        int pisos = salones / salonesPorPiso;
        if (salones % salonesPorPiso > 0) {
            pisos++;
        }
        return pisos;
    }
}
