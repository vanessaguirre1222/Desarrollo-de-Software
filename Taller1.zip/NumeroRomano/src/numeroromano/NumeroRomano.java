/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numeroromano;

import java.util.Scanner;


public class NumeroRomano {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese un numero entero entre 1 y 99:");
        int numero = scanner.nextInt();

        if (numero >= 1 && numero <= 99) {
            String romano = convertirARomano(numero);
            System.out.println("El numero " + numero + " en romano es: " + romano);
        } else {
            System.out.println("Numero invalido. Ingrese un numero entre 1 y 99.");
        }
    }

    public static String convertirARomano(int numero) {
        int decenas = numero / 10;
        int unidades = numero % 10;
        return convertirDecenasARomano(decenas) + convertirUnidadesARomano(unidades);
    }

    public static String convertirUnidadesARomano(int unidad) {
        String[] romanos = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
        return romanos[unidad];
    }

    public static String convertirDecenasARomano(int decena) {
        String[] romanos = {"", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"};
        return romanos[decena];
    }
}
