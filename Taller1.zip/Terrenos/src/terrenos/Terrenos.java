/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package terrenos;

/**
 *
 * @author SALA
 */
public class Terrenos {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        double a = 5.0; 
        double b = 3.0;
        double c = 4.0;

        double areaTerreno = area(a, b, c);
        double perimetroTerreno = calcularPerimetro(a, b, c);

        System.out.println("El area del terreno es: " + areaTerreno);
        System.out.println("El perimetro del terreno es: " + perimetroTerreno);
    }
    
    public static double calcularAreaTriangulo(double a, double b, double c){
    
    return (b * (a-c)) / 2;
    }
    
    public static double calcularAreaRectangulo(double b, double c){
    
    return b * c;
    }
    
    public static double calcularHipotenusa(double a, double b) {
        
        return Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
    }
    
        public static double calcularPerimetro(double a, double b, double c) {
        return a + b + c + calcularHipotenusa(a , b) ;
    }
        public static double area (double a, double b, double c) {
        return calcularAreaTriangulo(a,b,c) + calcularAreaRectangulo(b,c);
    } 
    
}
