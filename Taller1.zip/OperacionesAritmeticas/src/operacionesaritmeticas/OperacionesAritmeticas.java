package operacionesaritmeticas;

import java.util.Scanner;

public class OperacionesAritmeticas {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Ingrese el primer numero:");
        int numero1 = scanner.nextInt();
        System.out.println("Ingrese el segundo numero:");
        int numero2 = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese la operacion (+, -, *, /, %, **):");
        String operador = scanner.nextLine();
        
        try {
            double resultado = realizarOperacion(numero1, numero2, operador);
            System.out.println("El resultado es: " + resultado);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static double realizarOperacion(int num1, int num2, String operador) throws Exception {
        switch (operador) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                if (num2 == 0) {
                    throw new IllegalArgumentException("Division por cero.");
                }
                return (double) num1 / num2;
            case "%":
                return num1 % num2;
            case "**":
                return Math.pow(num1, num2);
            default:
                throw new IllegalArgumentException("Operador no valido.");
        }
    }
}
