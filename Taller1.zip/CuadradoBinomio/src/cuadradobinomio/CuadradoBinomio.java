package cuadradobinomio;

public class CuadradoBinomio {

    
    public static int cuadradoDeBinomio(int a, int b) {
        
        return a*a + b*b + 2*a*b ; 
    }

    public static void main(String[] args) {
        int a = 3;
        int b = 2;
        
        System.out.println("El cuadrado del binomio (a + b)^2 es: " + cuadradoDeBinomio(a, b));
    }
}

