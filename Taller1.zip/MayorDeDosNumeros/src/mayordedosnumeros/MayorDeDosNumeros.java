/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mayordedosnumeros;

import java.util.Scanner;

public class MayorDeDosNumeros {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Ingrese el primer numero entero:");
        int numero1 = scanner.nextInt();
        System.out.println("Ingrese el segundo numero entero:");
        int numero2 = scanner.nextInt();
        
        int mayor = encontrarMayor(numero1, numero2);
        System.out.println("El mayor de los dos uúmeros es: " + mayor);
    }

    public static int encontrarMayor(int num1, int num2) {
        if (num1 > num2) {
            return num1;
        } else {
            return num2;
        }
    }
}

